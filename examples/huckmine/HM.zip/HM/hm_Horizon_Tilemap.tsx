<?xml version="1.0" encoding="UTF-8"?>
<tileset name="hm_Horizon_Tilemap" tilewidth="8" tileheight="8" tilecount="512" columns="16">
 <image source="hm_Horizon_Tilemap.png" width="128" height="256"/>
</tileset>
